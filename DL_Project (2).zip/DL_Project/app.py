from tensorflow.keras.models import load_model

# Load the trained model
model = load_model('encoder_decoder_model.h5')

import pickle

# Load tokenizers if saved
with open('input_tokenizer.pkl', 'rb') as f:
    input_tokenizer = pickle.load(f)

with open('output_tokenizer.pkl', 'rb') as f:
    output_tokenizer = pickle.load(f)

    # Example input text
test_input_text = "Your test input sentence."

# Preprocess the input
input_seq = input_tokenizer.texts_to_sequences([test_input_text])
input_seq = pad_sequences(input_seq, maxlen=max_input_length, padding='post')

# Decode the sequence
summary = decode_sequence(input_seq)
print("Input:", test_input_text)
print("Summary:", summary)